# before running this one must update the path to point to the right directory
export PYTHONPATH=$PYTHONPATH:/path/to/XyceSrcDirectory/utils/XyceCInterface
