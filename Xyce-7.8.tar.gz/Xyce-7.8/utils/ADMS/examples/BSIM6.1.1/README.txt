
The BSIM6.1.1 package contains the following files:

/README.txt
This document

 
/BSIM6.1.1 Technical Note.pdf
The BSIM6.1.1 Technical Note (or user's manual).
 
/Benchmark_test/*.sp
Sample netlists for HSPICE

/Benchmark_test/*.lis
Sample output files

/Benchmark_test/modelcard.nmos
Sample model card for nmos


/Benchmark_test/modelcard.pmos
Sample model card for pmos




